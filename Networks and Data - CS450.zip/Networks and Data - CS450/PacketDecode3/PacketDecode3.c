#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>


int main(int argc, char* argv[]) {
	int returnCode = 0;		  // Relevant return code [negative values indicate errors]
	FILE* fp;			      // File pointer
	int byte;			      // Actual byte read from file
	int payloadByteCount = 0; // Payload byte counter

	int ihl = 0;         // Internet Header Length
	int ecn = 0;         // Explicit Congestion Notification
	int id = 0;			 // Identification
	int flags = 0;       // Flags for IPv4 Header
	int totalLen = 0;    // Total Length
	int ipCheckSum = 0;  // IP Checksum
	int fragOff = 0;     // Fragment Offset

	int srcPort = 0;			   // Source Port
	int destPort = 0;			  // Destination Port
	unsigned int sequenceNum = 0; // Sequence Number
	unsigned int ackNum = 0;      // Acknowledgment Number
	int checkSum = 0;			  // TCP Checksum
	int urgentPtr = 0;			  // Urgent Pointer
	int windowSize = 0;			  // Window Size
	int dataOffset = 0;			  // Data Offset



	// Command line arguement is incorrect
	if (argc < 2) {
		printf("Error: No filename provided.\n");
		printf("Usage: %s <binary file>\n", argv[0]);
		returnCode = -1;
		// Command line is correct
	}
	else {
		fp = fopen(argv[1], "rb");
		// Cannot open the binary file
		if (!fp) {
			printf("Error opening file %s\n", argv[1]);
			perror("fopen");
			returnCode = -2;
			// File opened successfully - begin decoding
		}
		else {
			printf("Decoding file: %s\n", argv[1]);
			//printf("\n");

// =====================================================
// Ethernet Header 
// =====================================================

			printf("Ethernet Header:\n");
			printf("--------------------------------------------------\n");
			//printf("\n");

			printf("Destination MAC Address: \t");

			// Read sequentially one byte at a time until EOF

			// DESTINATION MAC ADDRESS (Bytes 1 - 6)
			// --------------------------------------------------
			for (int i = 0; i < 5; i++) {
				byte = fgetc(fp);
				printf("%02X", byte); // <- Print the byte in hex format
				printf(":"); 	  // <- Print a colon after every byte except the last
			}

			// Last byte of Destination MAC field (byte 6) without colon
			byte = fgetc(fp);
			printf("%02X", byte);


			printf("\n");
			printf("Source MAC Address: \t\t");

			// SOURCE MAC ADDRESS (Bytes 7 - 12)
			// --------------------------------------------------

			for (int i = 0; i < 5; i++) {
				byte = fgetc(fp);
				printf("%02X", byte); // <- Print the byte in hex format
				printf(":"); 	  // <- Print a colon after every byte except the last
			}

			// Last byte of Source MAC field (byte 12) without colon
			byte = fgetc(fp);
			printf("%02X", byte);


			printf("\n");
			printf("Type: \t\t\t\t");

			// TYPE (Bytes 13 - 14)
			// --------------------------------------------------

			for (int i = 0; i < 2; i++) {
				printf("%02X", fgetc(fp));  // <- Print the byte in hex format
			}



	// =====================================================
	// IPv4 Header 
	// =====================================================


			printf("\n\n");
			printf("IPv4 Header:\n");
			printf("--------------------------------------------------\n");

			// Version (First 3 Bits of Byte 15)
			// --------------------------------------------------
			printf("Version: \t\t\t");
			byte = fgetc(fp);
			printf("%02X", (byte >> 4) & 0x0F);	// <- Shift right to get the first 4 bits


			// IHL (Last 5 Bits of Byte 15)
			// --------------------------------------------------
			printf("\nInternet Header Length: \t");
			byte = byte & 0x0F;			// <- Mask to get the last 4 bits
			printf("%02X", byte);
			ihl = byte - 5;             // <- Subtract 5 to get number of option words (if any)


			// DSCP (First 6 Bits of Byte 16)
			// --------------------------------------------------
			printf("\nDSCP: \t\t\t\t");
			byte = fgetc(fp);
			printf("%02X", (byte >> 2) & 0x3F);	 // <- Shift right to get the first 6 bits


			// ECN (Last 2 Bits of Byte 16)
			// --------------------------------------------------
			printf("\nECN: \t\t\t\t");
			ecn = byte & 0x03;			// <- Mask to get the last 2 bits
			printf("%02X", ecn);

			if (ecn == 3) {				// <- ECN value of (11) indicates congestion experienced
				printf("\tCongestion Experienced!");
			}
			else if (ecn == 2 || ecn == 1) { // <- No congestion (01) or (10)
				printf("\tECT Capable");
			}
			else {
				printf("\tNon-ECT Packet"); // <- Not a ECN packet (00)
			}


			// Total Length (Bytes 17 - 18)
			// --------------------------------------------------
			for (int i = 0; i < 2; i++) {
				byte = fgetc(fp);
				totalLen = (totalLen << 8) | byte; // <- Shift left and add the new byte
			}
			printf("\nTotal Length: \t\t\t%u", totalLen);


			// Identification (Bytes 19 - 20)
			// --------------------------------------------------
			printf("\nIdentification: \t\t");
			
			byte = fgetc(fp);
			id |= (byte & 0xFF) << 8;        // High-order byte
			
			byte = fgetc(fp);
			id |= (byte & 0xFF);          // Low-order byte

			printf("%u", id);


			// Flags (First 3 Bits of Byte 21)
			// --------------------------------------------------
			printf("\nFlags: \t\t\t\t");
			byte = fgetc(fp);
			flags = (byte >> 5) & 0x07;				// Bit shift to get the first 3 bits


			// Print flags text per your original style
			if (flags == 2) {
				printf("Don't Fragment");            // DF set (010)
			}
			else if (flags == 1) {
				printf("More Fragment");             // MF set (001)
			}
			else if (flags >= 3) {
				printf("Bit Error");                 // DF and MF set (011 or reserved bits)
				returnCode = -3;
			}
			else {
				printf("No Flags Set");              // No Flags (000)
			}

			// Fragment Offset (Last 5 Bits of Byte 21 + All of Byte 22)
			// --------------------------------------------------
			fragOff = (byte & 0x1F) << 8;
			byte = fgetc(fp);
			fragOff += byte;			// <- Combine last 5 bits of byte 21 and all of byte 22
			printf("\nFragment Offset: \t\t%u", fragOff);


			// Time to Live (Byte 23)
			// --------------------------------------------------
			printf("\nTime to Live: \t\t\t");
			printf("%d", fgetc(fp));

			// Protocol (Byte 24)
			// --------------------------------------------------
			printf("\nProtocol: \t\t\t");
			printf("%d", fgetc(fp));

			// IP Checksum (Bytes 25 - 26)
			// --------------------------------------------------
			byte = fgetc(fp);
			ipCheckSum = (byte & 0xFF) << 8;    // High-order byte

			byte = fgetc(fp);
			ipCheckSum |= (byte & 0xFF);        // Low-order byte

			printf("\nIP Checksum: \t\t\t0x%04X", ipCheckSum);

			// Source IP Address (Bytes 27 - 30)
			// --------------------------------------------------
			printf("\nSource IP Address: \t\t");
			for (int i = 0; i < 3; i++) {
				printf("%d", fgetc(fp));   // <- Print the byte in decimal format
				printf("."); 						// <- Print a dot after every byte except the last
			}
			printf("%d", fgetc(fp));

			// Destination IP Address (Bytes 31 - 34)
			// --------------------------------------------------
			printf("\nDestination IP Address: \t");
			for (int i = 0; i < 3; i++) {
				printf("%d", fgetc(fp));    // <- Print the byte in decimal format
				printf("."); 						// <- Print a dot after every byte except the last
			}
			printf("%d", fgetc(fp));

			// Options (Bytes 35 - ?)
			// --------------------------------------------------
			if (ihl == 0) {
				printf("\nOptions: \t\t\t");
				printf("No Options\n");
			}
			else {
				for (int i = 0; i < ihl; i++) {
					printf("\nIP Option Word #%d: \t\t", i);
					printf("0x");

					for (int j = 1; j <= 4; j++) { // <- Read the next 4 bytes to complete the word

						byte = fgetc(fp);
						printf("%02X", byte);  // <- Print the byte in hex format
					}

				}
			}

	// =====================================================
	// TCP Header 
	// =====================================================

			printf("\n\n");
			printf("TCP Header:\n");
			printf("--------------------------------------------------\n");

			// Source Port (2 Bytes)
			// --------------------------------------------------

			byte = fgetc(fp);                   // First byte
			srcPort = (byte & 0xFF) << 8;      // High-order byte

			byte = fgetc(fp);                   // Second byte
			srcPort |= (byte & 0xFF);           // Low-order byte

			printf("Source Port: \t\t\t%u\n", srcPort);

			// Destination Port (2 Bytes)
			// --------------------------------------------------

			byte = fgetc(fp);                   // First byte
			destPort = (byte & 0xFF) << 8;     // High-order byte

			byte = fgetc(fp);                   // Second byte
			destPort |= (byte & 0xFF);          // Low-order byte

			printf("Destination Port: \t\t%u\n", destPort);

			// Sequence Number (4 Bytes)
			// --------------------------------------------------

			printf("Raw Sequence Number: \t\t");
			for (int i = 0; i < 4; i++) {
				byte = fgetc(fp);
				sequenceNum = (sequenceNum << 8) | (byte & 0xFF); // <- Shift left and add the new byte
			}
			printf("%u\n", sequenceNum);

			// Acknowledgment Number (4 Bytes)
			// --------------------------------------------------
			printf("Raw Acknowledgment Number: \t");
			for (int i = 0; i < 4; i++) {
				byte = fgetc(fp);
				ackNum = (ackNum << 8) | (byte & 0xFF); // <- Shift left and add the new byte
			}
			printf("%u\n", ackNum);

			// Data Offset + Reserved (1 Byte)
			// --------------------------------------------------
			printf("Data Offset: \t\t\t");
			byte = fgetc(fp);
			dataOffset = (byte >> 4) & 0x0F; // <- Shift right to get the first 4 bits
			printf("%d", dataOffset); // <- Shift right to get the first 4 bits

			// ** Reserved Bits (Last 4 Bits of the Same Byte) **
			//printf("\n");
			//printf("Reserved: \t\t\t");
			//printf("%02X", byte & 0x0F);        // <- Mask to get the last 4 bits
			printf("\n");

			// Flags (1 Byte)
			// --------------------------------------------------
			byte = fgetc(fp);
			printf("Flags: \t\t\t\t");

			// Prints each flipped flag
			if (byte & 0x01) printf("FIN ");
			if (byte & 0x02) printf("SYN ");
			if (byte & 0x04) printf("RST ");
			if (byte & 0x08) printf("PSH ");
			if (byte & 0x10) printf("ACK ");
			if (byte & 0x20) printf("URG ");
			if (byte & 0x40) printf("ECE ");
			if (byte & 0x80) printf("CWR ");

			// Window Size (2 Bytes)
			// --------------------------------------------------

			byte = fgetc(fp);
			windowSize = (byte & 0xFF) << 8;    // High-order byte

			byte = fgetc(fp);
			windowSize |= (byte & 0xFF);        // Low-order byte

			printf("\nWindow Size: \t\t\t%u\n", windowSize);

			// Checksum (2 Bytes)
			// --------------------------------------------------

			byte = fgetc(fp);
			checkSum |= (byte & 0xFF) << 8;      // High-order byte
			
			byte = fgetc(fp);
			checkSum |= (byte & 0xFF);          // Low-order byte

			printf("TCP Checksum: \t\t\t0x%04X\n", checkSum);

						

			// Urgent Pointer (2 Bytes)
			// --------------------------------------------------

			byte = fgetc(fp);
			urgentPtr = (byte & 0xFF) << 8;     // High-order byte

			byte = fgetc(fp);
			urgentPtr |= (byte & 0xFF);         // Low-order byte

			printf("Urgent Pointer: \t\t%d\n", urgentPtr);
			
			// Options (Variable Length)
			// --------------------------------------------------
			dataOffset -= 5; // Subtract 5 to get number of option words (if any)
			if (dataOffset <= 0) {
				printf("Options: \t\t\t");
				printf("No Options\n");
			}
			else {
				for (int i = 0; i < dataOffset; i++) {
					printf("TCP Option Word #%d: \t\t", i);
					printf("0x");
					for (int j = 1; j <= 4; j++) { // <- Read the next 4 bytes to complete the word
						byte = fgetc(fp);
						printf("%02X", byte);  // <- Print the byte in hex format
					}
					printf("\n");
				}
			}


			printf("\n\n");
			printf("Payload:\n");

			// ==================================================
			// PAYLOAD
			// ==================================================

			while ((byte = fgetc(fp)) != EOF) {

				payloadByteCount++;
				printf("%02X ", byte);

				if (payloadByteCount % 32 == 0) {
					printf("\n");          // Newline every 32 bytes
				}
				else if (payloadByteCount % 8 == 0) {
					printf(" ");           // Space every 8 bytes
				}
			}

			fclose(fp); // Close the file
			
		}

	}
	// Returns relevant return codeSo
	return returnCode;
}

