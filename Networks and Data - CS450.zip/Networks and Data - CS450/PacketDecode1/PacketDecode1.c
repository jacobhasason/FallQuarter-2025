#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>


int main(int argc, char* argv[]) {
	int returnCode = 0;   // Relevant return code [negative values indicate errors]
	FILE* fp;             // File pointer
	int byte;             // Actual byte read from file
	int bytePos = 0;      // Position of byte in file
	int colGroup = 0;     // Column group for printing payload

	// Command line arguement is incorrect
	if (argc < 2) {
		printf("Error: No filename provided.\n");
		printf("Usage: %s <binary file>\n", argv[0]);
		returnCode = -1;
	// Command line is correct
	} else {
		fp = fopen(argv[1], "rb");
		// Cannot open the binary file
		if (!fp) {
			printf("Error opening file %s\n", argv[1]);
			perror("fopen");
			returnCode = -2;
		// File opened successfully - begin decoding
		} else {
			printf("Decoding file: %s\n", argv[1]);
			printf("\n");

			printf("Ethernet Header:\n");
			printf("--------------------------------------------------\n");
			printf("\n");

			printf("Destination MAC Address: \t");

			// Read sequentially one byte at a time until EOF
			while ((byte = fgetc(fp)) != EOF) {
				bytePos++;

			// DESTINATION MAC ADDRESS (Bytes 1 - 6)
			// --------------------------------------------------
				if (bytePos <= 6) {
					printf("%02X", byte); // <- Print the byte in hex format
					if (bytePos < 6) {
						printf(":"); 	  // <- Print a colon after every byte except the last
					}
					else {
						printf("\n\n");
						printf("Source MAC Address: \t\t");
					}
			// SOURCE MAC ADDRESS (Bytes 7 - 12)
			// --------------------------------------------------
				} else if (bytePos <= 12) {
					printf("%02X", byte);
					if (bytePos < 12) {
						printf(":");
					}
					else {
						printf("\n\n");
						printf("Type: \t\t\t\t");
					}
				// TYPE (Bytes 13 - 14)
				// --------------------------------------------------
				}
				else if (bytePos <= 14) {
					if (bytePos < 14) {
						// First (high-order) byte of the Type
						printf("%02X", byte);
					} else {
						// Second (low-order) byte of the Type
						printf("%02X\n", byte);
						printf("\n");
						printf("Payload:\n");
						printf("\n");
					}
				// PAYLOAD (Bytes 15 - ...)
				// --------------------------------------------------
				}
				else if (bytePos >= 15) {
					// Print the byte in hex format
					printf("%02X ", byte);

					// Extra space every 8 bytes for readability
					if ((bytePos - 14) % 8  == 0) {
						printf("  ");
						colGroup++;
					}
					// New line every 32 bytes for readability
					if (colGroup == 4) {
						printf("\n");
						colGroup = 0;
					}
				}
			}

			fclose(fp); // Close the file
			printf("\n");
			printf("\n");
			printf("Decoding successfully completed!\n");
			returnCode = 1;
		}

	}
	// Displays relevant return code
	printf("return code: %i\n", returnCode);
	return returnCode;



}